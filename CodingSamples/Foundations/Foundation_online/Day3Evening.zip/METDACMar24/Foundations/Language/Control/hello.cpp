#include <cstdio>

int main(void)
{
	puts("Hello World!");
	puts("Goodbye.");
}

