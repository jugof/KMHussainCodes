#include "common.h"

int main(void)
{
	PutMsg("Hello World!\n");
}

